import 'dart:convert';
import 'dart:io';
import 'dart:async';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as path;

import '../../db/database_helper.dart';
import '../../utils/app_settings.dart';
import '../sync_models.dart';
import 'sync_discovery_service.dart';

class SyncService {
  SyncService._();

  static final SyncService instance = SyncService._();
  static final ValueNotifier<SyncStatus> _statusNotifier =
      ValueNotifier<SyncStatus>(SyncStatus.disconnected);
  static ValueNotifier<SyncStatus> get statusNotifier => _statusNotifier;

  static final ValueNotifier<List<SyncLogEntry>> _logNotifier =
      ValueNotifier<List<SyncLogEntry>>(const []);
  static ValueNotifier<List<SyncLogEntry>> get logNotifier => _logNotifier;

  static const int _maxLogEntries = 250;

  void _log(String direction, String message) {
    final next = [
      ..._logNotifier.value,
      SyncLogEntry(
        time: DateTime.now(),
        direction: direction,
        message: message,
      ),
    ];
    if (next.length > _maxLogEntries) {
      next.removeRange(0, next.length - _maxLogEntries);
    }
    _logNotifier.value = List.unmodifiable(next);
    debugPrint('SYNC [$direction] $message');
  }

  void clearLogs() => _logNotifier.value = const [];

  HttpServer? _server;
  Timer? _timer;
  bool _running = false;
  bool _syncing = false;
  String? _lastError;
  DateTime? _lastPeerActivity;

  SyncStatus get status => _statusNotifier.value;
  String? get lastError => _lastError;

  Future<void> initialize() async {
    if (_running) return;
    _running = true;

    await DatabaseHelper.database;
    await DatabaseHelper.ensureSyncIdentity();

    final enabled = await AppSettings.getSyncEnabled();
    if (enabled) {
      await SyncDiscoveryService.instance.start();
      await start();

      // بازسازی اطلاعات legacy در پس‌زمینه انجام می‌شود تا
      // دیتابیس‌های بزرگ باعث تأخیر در باز شدن فرم اصلی نشوند.
      unawaited(() async {
        try {
          await DatabaseHelper.ensureSyncIdentity(rebuildLegacyChanges: true);
        } catch (e, st) {
          debugPrint('Background sync identity repair error: $e');
          debugPrintStack(stackTrace: st);
        }
      }());
    }
  }

  Future<void> start() async {
    if (!_running) _running = true;
    await SyncDiscoveryService.instance.start();

    if (_server == null) {
      final port = await AppSettings.getSyncPort();
      try {
        _server = await HttpServer.bind(
          InternetAddress.anyIPv4,
          port,
          shared: true,
        );
        _log('✓', 'سرور هماهنگ‌سازی روی پورت $port فعال شد');
        _server!.listen(
          _handleRequest,
          onError: (_) {
            _setStatus(SyncStatus.error, 'خطا در سرور هماهنگ‌سازی');
          },
        );
      } catch (e) {
        _log('!', 'سرور روی پورت $port اجرا نشد: $e');
        _lastError = 'امکان باز کردن پورت هماهنگ‌سازی وجود ندارد: $e';
        _setStatus(SyncStatus.error, _lastError);
        return;
      }
    }

    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 15), (_) async {
      final role = await AppSettings.getSyncRole();
      if (role == 'master') {
        final last = _lastPeerActivity;
        if (last == null ||
            DateTime.now().difference(last) > const Duration(seconds: 35)) {
          _setStatus(SyncStatus.disconnected);
        }
      } else {
        await syncNow();
      }
    });
    await syncNow();
  }

  Future<void> stop() async {
    _timer?.cancel();
    _timer = null;
    await SyncDiscoveryService.instance.stop();
    await _server?.close(force: true);
    _server = null;
    _setStatus(SyncStatus.disconnected);
  }

  Future<void> syncNow() async {
    if (_syncing) return;
    final enabled = await AppSettings.getSyncEnabled();
    if (!enabled) {
      _setStatus(SyncStatus.disconnected);
      return;
    }

    var host = await AppSettings.getSyncPeerHost();
    final role = await AppSettings.getSyncRole();
    final key = await AppSettings.getSyncKey();

    // Client devices can now find the master automatically. The pairing key
    // is still required for authentication; discovery only replaces manual IP entry.
    if ((host == null || host.isEmpty) && role == 'client') {
      final peers = await SyncDiscoveryService.instance.discover();
      if (peers.isNotEmpty) {
        final peer = peers.first;
        host = peer.host;
        await AppSettings.setSyncPeerHost(peer.host);
        await AppSettings.setSyncPeerPort(peer.port);
      }
    }

    if ((host == null || host.isEmpty) && role == 'master') {
      return;
    }
    if (host == null || host.isEmpty || key.isEmpty) {
      _setStatus(SyncStatus.disconnected);
      return;
    }

    _syncing = true;
    _setStatus(SyncStatus.connecting);

    final port = await AppSettings.getSyncPeerPort();

    _log('→', 'شروع هماهنگ‌سازی با $host:$port');

    try {
      await _requestJson('GET', '/sync/info', host: host, port: port, key: key);
      _setStatus(SyncStatus.syncing);

      await _pullRemote(host, port, key);
      await _pushLocal(host, port, key);
      await _syncFiles(host, port, key);

      await AppSettings.setSyncLastSuccess(DateTime.now());
      _setStatus(SyncStatus.connected);
      _lastError = null;
      _log('✓', 'هماهنگ‌سازی با موفقیت انجام شد');
    } catch (e) {
      _lastError = e.toString();
      _log('!', 'خطا: $e');
      _setStatus(SyncStatus.error, _lastError);
    } finally {
      _syncing = false;
    }
  }

  Future<void> _pullRemote(String host, int port, String key) async {
    final cursor = await AppSettings.getSyncPeerPullCursor();
    final response = await _requestJson(
      'GET',
      '/sync/pull?after=$cursor',
      host: host,
      port: port,
      key: key,
    );

    final changes = (response['changes'] as List? ?? const [])
        .whereType<Map>()
        .map((e) => SyncChange.fromMap(Map<String, dynamic>.from(e)))
        .toList();

    if (changes.isNotEmpty) {
      _log('↓', '${changes.length} تغییر از دستگاه مقابل دریافت شد');
    }

    for (final change in changes) {
      if (change.deviceId == await AppSettings.getDeviceId()) continue;
      await DatabaseHelper.applySyncChange(change);
    }

    final remoteCursor = (response['last_id'] as num?)?.toInt();
    if (remoteCursor != null && remoteCursor >= cursor) {
      await AppSettings.setSyncPeerPullCursor(remoteCursor);
    }
  }

  Future<void> _pushLocal(String host, int port, String key) async {
    final cursor = await AppSettings.getSyncPeerPushCursor();
    final changes = await DatabaseHelper.getSyncChangesAfter(
      cursor,
      limit: 100,
    );
    if (changes.isEmpty) return;

    _log('↑', 'ارسال ${changes.length} تغییر به دستگاه مقابل');
    final response = await _requestJson(
      'POST',
      '/sync/push',
      host: host,
      port: port,
      key: key,
      body: {'changes': changes.map((e) => e.toMap()).toList()},
    );

    if (response['ok'] == true) {
      final last = changes.last.id;
      await AppSettings.setSyncPeerPushCursor(last);
    }
  }

  Future<void> _syncFiles(String host, int port, String key) async {
    final localManifest = await _buildFileManifest();
    final receiveOldFiles = await AppSettings.getSyncReceiveOldFiles();
    final filesSince = await AppSettings.getSyncFilesSince();

    final remote = await _requestJson(
      'POST',
      '/sync/files/manifest',
      host: host,
      port: port,
      key: key,
      body: {
        'files': localManifest,
        'receive_old_files': receiveOldFiles,
        'files_since': filesSince?.toUtc().toIso8601String(),
      },
    );

    final missing = (remote['need_upload'] as List? ?? const [])
        .whereType<Map>()
        .map((e) => Map<String, dynamic>.from(e));

    for (final item in missing) {
      final rel = item['path']?.toString();
      if (rel == null || rel.isEmpty) continue;
      final root = await AppSettings.getLettersDirectory();
      final file = File(path.join(root.path, rel));
      if (!await file.exists()) continue;
      final bytes = await file.readAsBytes();
      final client = HttpClient();
      final req = await client.post(host, port, '/sync/file');
      final timestamp = DateTime.now().millisecondsSinceEpoch.toString();
      req.headers.set('x-sync-timestamp', timestamp);
      req.headers.set(
        'x-sync-signature',
        _sign(key, timestamp, 'POST', '/sync/file', base64Encode(bytes)),
      );
      req.headers.set('x-sync-path', Uri.encodeComponent(rel));
      req.headers.contentType = ContentType('application', 'octet-stream');
      req.add(bytes);
      final res = await req.close();
      await res.drain();
      _log('↑', 'فایل ارسال شد: $rel (HTTP ${res.statusCode})');
    }

    final remoteOnly = (remote['need_download'] as List? ?? const [])
        .whereType<Map>()
        .map((e) => Map<String, dynamic>.from(e));

    for (final item in remoteOnly) {
      final rel = item['path']?.toString();
      if (rel == null || rel.isEmpty) continue;
      await _downloadFile(host, port, key, rel);
    }
  }

  Future<List<Map<String, dynamic>>> _buildFileManifest() async {
    final root = await AppSettings.getLettersDirectory();
    if (!await root.exists()) return [];
    final result = <Map<String, dynamic>>[];
    await for (final entity in root.list(recursive: true, followLinks: false)) {
      if (entity is! File) continue;
      final rel = path
          .relative(entity.path, from: root.path)
          .replaceAll('\\', '/');
      final stat = await entity.stat();
      final bytes = await entity.readAsBytes();
      final hash = sha256.convert(bytes).toString();
      result.add({
        'path': rel,
        'sha256': hash,
        'size': bytes.length,
        'modified_at': stat.modified.toUtc().toIso8601String(),
      });
    }
    return result;
  }

  Future<void> _downloadFile(
    String host,
    int port,
    String key,
    String rel,
  ) async {
    final client = HttpClient();
    try {
      final route = '/sync/file?path=${Uri.encodeQueryComponent(rel)}';
      final timestamp = DateTime.now().millisecondsSinceEpoch.toString();
      final req = await client.get(host, port, route);
      req.headers.set('x-sync-timestamp', timestamp);
      req.headers.set(
        'x-sync-signature',
        _sign(key, timestamp, 'GET', route, ''),
      );
      final res = await req.close();
      if (res.statusCode != 200) {
        _log('!', 'دریافت فایل ناموفق بود: $rel (HTTP ${res.statusCode})');
        return;
      }
      final bytes = await res.fold<List<int>>(<int>[], (a, b) => a..addAll(b));
      final root = await AppSettings.getLettersDirectory();
      final target = File(path.join(root.path, rel));
      await target.parent.create(recursive: true);
      if (await target.exists()) {
        final existingHash = sha256
            .convert(await target.readAsBytes())
            .toString();
        if (existingHash == sha256.convert(bytes).toString()) return;
      }
      await target.writeAsBytes(bytes, flush: true);
      _log('↓', 'فایل دریافت شد: $rel');
    } finally {
      client.close(force: true);
    }
  }

  String _sign(
    String key,
    String timestamp,
    String method,
    String route,
    String body,
  ) {
    final mac = Hmac(sha256, utf8.encode(key));
    return mac
        .convert(utf8.encode('$timestamp|$method|$route|$body'))
        .toString();
  }

  Future<Map<String, dynamic>> _requestJson(
    String method,
    String route, {
    required String host,
    required int port,
    required String key,
    Map<String, dynamic>? body,
  }) async {
    final client = HttpClient();
    try {
      final req = method == 'GET'
          ? await client.get(host, port, route)
          : await client.post(host, port, route);
      final bodyText = body == null ? '' : jsonEncode(body);
      final timestamp = DateTime.now().millisecondsSinceEpoch.toString();
      req.headers.set('x-sync-timestamp', timestamp);
      req.headers.set(
        'x-sync-signature',
        _sign(key, timestamp, method, route, bodyText),
      );
      req.headers.contentType = ContentType.json;
      if (bodyText.isNotEmpty) req.write(bodyText);
      final res = await req.close();
      final text = await res.transform(utf8.decoder).join();
      if (res.statusCode < 200 || res.statusCode >= 300) {
        throw Exception(text.isEmpty ? 'HTTP ${res.statusCode}' : text);
      }
      return text.isEmpty
          ? <String, dynamic>{}
          : Map<String, dynamic>.from(jsonDecode(text) as Map);
    } finally {
      client.close(force: true);
    }
  }

  Future<void> _handleRequest(HttpRequest request) async {
    try {
      final key = await AppSettings.getSyncKey();
      final bodyBytes = request.method == 'POST'
          ? await request.fold<List<int>>(<int>[], (a, b) => a..addAll(b))
          : <int>[];
      final timestamp = request.headers.value('x-sync-timestamp') ?? '';
      final signature = request.headers.value('x-sync-signature') ?? '';
      final parsedTimestamp = int.tryParse(timestamp);
      final fresh =
          parsedTimestamp != null &&
          (DateTime.now().millisecondsSinceEpoch - parsedTimestamp).abs() <=
              120000;
      final bodyForSignature =
          request.method == 'POST' && request.uri.path == '/sync/file'
          ? base64Encode(bodyBytes)
          : utf8.decode(bodyBytes);
      final expected = _sign(
        key,
        timestamp,
        request.method,
        request.uri.toString(),
        bodyForSignature,
      );
      if (key.isEmpty || !fresh || signature != expected) {
        request.response.statusCode = HttpStatus.unauthorized;
        await request.response.close();
        return;
      }
      _lastPeerActivity = DateTime.now();
      _setStatus(SyncStatus.connected);
      _log(
        '←',
        '${request.method} ${request.uri.path} از ${request.connectionInfo?.remoteAddress.address ?? 'peer'}',
      );

      final uri = request.uri;
      if (uri.path == '/sync/info' && request.method == 'GET') {
        final role = await AppSettings.getSyncRole();

        await _writeJson(request, {
          'ok': true,
          'device_id': await AppSettings.getDeviceId(),
          'role': role,
          'port': await AppSettings.getSyncPort(),
        });

        return;
      }

      if (uri.path == '/sync/next-number' && request.method == 'POST') {
        final role = await AppSettings.getSyncRole();
        if (role != 'master') {
          request.response.statusCode = HttpStatus.forbidden;
          await request.response.close();
          return;
        }
        final next = await DatabaseHelper.reserveMasterLetterNumber();
        _log('←', 'شماره نامه $next برای دستگاه متصل رزرو شد');
        await _writeJson(request, {'ok': true, 'number': next});
        return;
      }

      if (uri.path == '/sync/pull' && request.method == 'GET') {
        final after = int.tryParse(uri.queryParameters['after'] ?? '') ?? 0;
        final changes = await DatabaseHelper.getSyncChangesAfter(
          after,
          limit: 100,
        );
        final last = await DatabaseHelper.getLastSyncChangeId();
        await _writeJson(request, {
          'ok': true,
          'last_id': last,
          'changes': changes.map((e) => e.toMap()).toList(),
        });
        return;
      }

      if (uri.path == '/sync/push' && request.method == 'POST') {
        final body = _readJsonBytes(bodyBytes);
        final changes = (body['changes'] as List? ?? const [])
            .whereType<Map>()
            .map((e) => SyncChange.fromMap(Map<String, dynamic>.from(e)));
        var count = 0;
        for (final change in changes) {
          await DatabaseHelper.applySyncChange(change);
          count++;
        }
        _log('←', '$count تغییر از دستگاه مقابل اعمال شد');
        await _writeJson(request, {'ok': true});
        return;
      }

      if (uri.path == '/sync/files/manifest' && request.method == 'POST') {
        final body = _readJsonBytes(bodyBytes);
        final incoming = (body['files'] as List? ?? const [])
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList();

        final peerReceivesOld = body['receive_old_files'] == true;
        final peerSince = DateTime.tryParse(
          body['files_since']?.toString() ?? '',
        );

        final local = await _buildFileManifest();
        final localMap = {for (final e in local) e['path'].toString(): e};
        final incomingMap = {for (final e in incoming) e['path'].toString(): e};

        bool eligibleForPeer(Map<String, dynamic> item) {
          if (peerReceivesOld) return true;
          final modified = DateTime.tryParse(
            item['modified_at']?.toString() ?? '',
          );
          return peerSince != null &&
              modified != null &&
              !modified.isBefore(peerSince.toUtc());
        }

        final missing = <Map<String, dynamic>>[];
        for (final e in local) {
          if (!eligibleForPeer(e)) continue;
          final remote = incomingMap[e['path'].toString()];
          if (remote == null || remote['sha256'] != e['sha256']) {
            missing.add(e);
          }
        }

        final receiveOldLocally = await AppSettings.getSyncReceiveOldFiles();
        final localSince = await AppSettings.getSyncFilesSince();

        bool eligibleForLocal(Map<String, dynamic> item) {
          if (receiveOldLocally) return true;
          final modified = DateTime.tryParse(
            item['modified_at']?.toString() ?? '',
          );
          return localSince != null &&
              modified != null &&
              !modified.isBefore(localSince.toUtc());
        }

        final remoteOnly = <Map<String, dynamic>>[];
        for (final e in incoming) {
          if (!eligibleForLocal(e)) continue;
          final localItem = localMap[e['path'].toString()];
          if (localItem == null || localItem['sha256'] != e['sha256']) {
            remoteOnly.add(e);
          }
        }

        _log(
          '↔',
          'بررسی فایل‌ها: ارسال ${remoteOnly.length}، دریافت ${missing.length}',
        );
        await _writeJson(request, {
          'ok': true,
          'need_upload': remoteOnly,
          'need_download': missing,
        });
        return;
      }

      if (uri.path == '/sync/file' && request.method == 'POST') {
        final rel = Uri.decodeComponent(
          request.headers.value('x-sync-path') ?? '',
        );
        if (rel.isEmpty || path.isAbsolute(rel) || rel.contains('..')) {
          request.response.statusCode = HttpStatus.badRequest;
          await request.response.close();
          return;
        }
        final bytes = bodyBytes;
        final root = await AppSettings.getLettersDirectory();
        final target = File(path.join(root.path, rel));
        await target.parent.create(recursive: true);
        await target.writeAsBytes(bytes, flush: true);
        _log('←', 'فایل دریافت شد: $rel');
        await request.response.close();
        return;
      }

      if (uri.path == '/sync/file' && request.method == 'GET') {
        final rel = uri.queryParameters['path'] ?? '';
        if (rel.isEmpty || path.isAbsolute(rel) || rel.contains('..')) {
          request.response.statusCode = HttpStatus.badRequest;
          await request.response.close();
          return;
        }
        final root = await AppSettings.getLettersDirectory();
        final file = File(path.join(root.path, rel));
        if (!await file.exists()) {
          request.response.statusCode = HttpStatus.notFound;
          await request.response.close();
          return;
        }
        request.response.headers.contentType = ContentType.binary;
        await request.response.addStream(file.openRead());
        await request.response.close();
        return;
      }

      request.response.statusCode = HttpStatus.notFound;
      await request.response.close();
    } catch (e) {
      request.response.statusCode = HttpStatus.internalServerError;
      request.response.write(jsonEncode({'ok': false, 'error': e.toString()}));
      await request.response.close();
    }
  }

  Map<String, dynamic> _readJsonBytes(List<int> bytes) {
    if (bytes.isEmpty) return {};
    final text = utf8.decode(bytes);
    if (text.trim().isEmpty) return {};
    return Map<String, dynamic>.from(jsonDecode(text) as Map);
  }

  Future<void> _writeJson(
    HttpRequest request,
    Map<String, dynamic> data,
  ) async {
    final response = request.response;

    response.headers.contentType = ContentType.json;
    response.add(utf8.encode(jsonEncode(data)));

    await response.close();
  }

  void _setStatus(SyncStatus value, [String? error]) {
    _lastError = error ?? _lastError;
    _statusNotifier.value = value;
  }
}
