import 'dart:io';
import 'package:dabirkhane/db/database_helper.dart';
import 'package:dabirkhane/services/notification_service.dart';
import 'package:dabirkhane/utils/CamScannerPathsTile.dart';
import 'package:dabirkhane/utils/ScannerTypeTile.dart';
import 'package:dabirkhane/utils/app_settings.dart';
import 'package:dabirkhane/utils/letter_file_organizer.dart';

import '../providers/theme_provider.dart';
import '../utils/LettersPathTile.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../ui/wid/ThemeColorTile.dart';
import 'schema_config_page.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  Future<void> restoreDbBackup(BuildContext context) async {
    try {
      // 1️⃣ مسیر دیتابیس اصلی و فایل بکاپ
      final String targetPath = await DatabaseHelper.getDbPath();
      final File targetFile = File(targetPath);
      final String backupPath = '$targetPath.backup';
      final File backupFile = File(backupPath);

      // 2️⃣ بررسی اینکه آیا فایل بکاپ وجود دارد یا نه
      if (!await backupFile.exists()) {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: Text('خطا'),
            content: Text('هیچ بکاپی برای بازیابی وجود ندارد.'),
            actions: [
              TextButton(
                child: Text('باشه'),
                onPressed: () => Navigator.pop(context),
              ),
            ],
          ),
        );
        return;
      }

      // 3️⃣ نمایش پیام تایید برای بازیابی (آیا مطمئن است که می‌خواهد داده‌ها را بازیابی کند؟)
      final confirm = await showConfirmationDialog(context);
      if (!confirm) {
        return;
      }

      // 4️⃣ بستن دیتابیس فعلی
      await DatabaseHelper.closeDb();

      // 5️⃣ حذف دیتابیس فعلی
      if (await targetFile.exists()) {
        await targetFile.delete();
      }

      // 6️⃣ کپی کردن فایل بکاپ به مسیر اصلی
      await backupFile.copy(targetPath);

      // 7️⃣ باز کردن دیتابیس جدید (بازیابی شده)
      await DatabaseHelper.database;

      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text('بازیابی موفقیت‌آمیز'),
          content: Text('دیتابیس با موفقیت بازیابی شد.'),
          actions: [
            TextButton(
              child: Text('باشه'),
              onPressed: () => Navigator.pop(context),
            ),
          ],
        ),
      );
    } catch (e) {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: Text('خطا'),
          content: Text(
            'بازیابی دیتابیس با خطا مواجه شد.\nلطفاً مطمئن شوید که فایل بکاپ سالم است.\n\n$e',
          ),
          actions: [
            TextButton(
              child: Text('باشه'),
              onPressed: () => Navigator.pop(context),
            ),
          ],
        ),
      );
      debugPrint(e.toString());
    }
  }

  Future<bool> showConfirmationDialog(BuildContext context) async {
    // اینجا می‌توانید از هر کدام از روش‌های تایید که دوست دارید استفاده کنید
    // برای مثال، استفاده از یک دیالوگ تایید برای کاربر
    return await showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('هشدار'),
              content: Text(
                'تمامی داده‌های فعلی پاک خواهند شد. آیا مطمئن هستید که می‌خواهید دیتابیس قبلی را بازیابی کنید؟',
              ),
              actions: <Widget>[
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop(false);
                  },
                  child: Text('خیر'),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop(true);
                  },
                  child: Text('بله'),
                ),
              ],
            );
          },
        ) ??
        false; // اگر دیالوگ بسته شود، مقدار پیش‌فرض false است
  }

  Future<Directory> getLettersDirectory() async {
    final appDir = await getApplicationDocumentsDirectory();
    final dir = Directory('${appDir.path}/letters');
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    return dir;
  }

  Future<void> organizeLetterFiles(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('مرتب‌سازی فایل‌های نامه'),
          content: const Text(
            'تمام فایل‌های موجود در پوشه نامه‌ها '
            'بر اساس تاریخ ثبت‌شده در دیتابیس مرتب می‌شوند.\n\n'
            'ساختار پوشه‌ها به صورت سال / ماه خواهد بود.\n\n'
            'آیا ادامه می‌دهید؟',
            textDirection: TextDirection.rtl,
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context, false);
              },
              child: const Text('انصراف'),
            ),
            FilledButton(
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: const Text('مرتب‌سازی'),
            ),
          ],
        );
      },
    );

    if (confirmed != true) {
      return;
    }

    if (!context.mounted) return;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) {
        return const AlertDialog(
          content: Row(
            children: [
              SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(),
              ),
              SizedBox(width: 20),
              Expanded(
                child: Text(
                  'در حال مرتب‌سازی فایل‌ها...',
                  textDirection: TextDirection.rtl,
                ),
              ),
            ],
          ),
        );
      },
    );

    try {
      final result = await LetterFileOrganizer.organizeAll();

      if (context.mounted) {
        Navigator.pop(context);
      }

      if (!context.mounted) return;

      showDialog(
        context: context,
        builder: (_) {
          return AlertDialog(
            title: const Text('مرتب‌سازی انجام شد'),
            content: Text(
              'فایل‌های منتقل‌شده: ${result.moved}\n'
              'فایل‌های ردشده: ${result.skipped}\n'
              'خطاها: ${result.errors}',
              textDirection: TextDirection.rtl,
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('باشه'),
              ),
            ],
          );
        },
      );
    } catch (e) {
      if (context.mounted) {
        Navigator.pop(context);
      }

      if (!context.mounted) return;

      showDialog(
        context: context,
        builder: (_) {
          return AlertDialog(
            title: const Text('خطا'),
            content: Text(
              'مرتب‌سازی فایل‌ها با خطا مواجه شد:\n\n$e',
              textDirection: TextDirection.rtl,
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('باشه'),
              ),
            ],
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تنظیمات')),
      body: ListView(
        children: [
          _sectionTitle('عمومی'),
          SwitchListTile(
            title: const Text('حالت تیره'),
            subtitle: const Text('فعال / غیرفعال کردن Dark Mode'),
            value: Theme.of(context).brightness == Brightness.dark,
            onChanged: (value) {
              context.read<ThemeProvider>().toggleDark(value);
            },
          ),

          ThemeColorTile(),

          const Divider(),

          _sectionTitle('فایل‌ها'),

          const LettersPathTile(),

          ListTile(
            leading: const Icon(Icons.folder_copy_outlined),
            title: const Text('مرتب‌سازی فایل‌های نامه‌ها'),
            subtitle: const Text(
              'دسته‌بندی فایل‌ها بر اساس سال و ماه ثبت نامه',
            ),
            trailing: const Icon(Icons.chevron_left),
            onTap: () {
              organizeLetterFiles(context);
            },
          ),

          const Divider(),
          _sectionTitle('دیتابیس'),
          ListTile(
            leading: const Icon(Icons.restore),
            title: const Text('بازیابی دیتابیس قبلی'),
            onTap: () {
              restoreDbBackup(context);
            },
          ),
          const Divider(),

          const MonthlyBackupReminderTile(),
          const Divider(),
          _sectionTitle('اسکنر'),
          const ScannerTypeTile(),
          const Divider(),
          const CamScannerPathsTile(),
          const SaveAndReturnAfterScanTile(),

          const Divider(),

          _sectionTitle('فرم نامه'),

          const AutoSaveRecordFormTile(),

          ListTile(
            leading: const Icon(Icons.dashboard_customize_outlined),
            title: const Text('ساختار و فیلدهای دبیرخانه'),
            subtitle: const Text('مدیریت فیلدها، چینش فرم، جستجو و آمار'),
            trailing: const Icon(Icons.chevron_left),
            onTap: () async {
              final changed = await Navigator.of(context).push<bool>(
                MaterialPageRoute(builder: (_) => const SchemaConfigPage()),
              );
              if (changed == true && context.mounted) {
                Navigator.of(context).pop(true);
              }
            },
          ),

          const Divider(),

          _sectionTitle('پیشنهاد تکمیل فرم'),

          const FormSuggestionsSettings(),

          const Divider(),
          const ReminderNotificationTimeTile(),

          ListTile(
            leading: const Icon(Icons.notifications_active_outlined),
            title: const Text('تست اعلان‌ها'),
            subtitle: const Text('بررسی و عیب‌یابی سرویس اعلان'),
            onTap: () async {
              showDialog(
                context: context,
                barrierDismissible: false,
                builder: (_) {
                  return const AlertDialog(
                    content: SizedBox(
                      height: 80,
                      child: Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            CircularProgressIndicator(),
                            SizedBox(height: 16),
                            Text('در حال بررسی اعلان‌ها...'),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              );

              final result = await NotificationService.instance
                  .debugInitialize();

              if (!context.mounted) return;

              Navigator.of(context).pop();

              showDialog(
                context: context,
                builder: (_) {
                  return AlertDialog(
                    title: const Row(
                      children: [
                        Icon(Icons.bug_report_outlined),
                        SizedBox(width: 8),
                        Text('نتیجه تست اعلان'),
                      ],
                    ),
                    content: SingleChildScrollView(
                      child: SelectableText(result),
                    ),
                    actions: [
                      TextButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        child: const Text('بستن'),
                      ),
                    ],
                  );
                },
              );
            },
          ),

          const Divider(),

          _sectionTitle('درباره برنامه'),
          ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text('نسخه برنامه'),
            subtitle: const Text('1.0.0'),
          ),
          ListTile(
            leading: const Icon(Icons.code),
            title: const Text('توسعه‌دهنده'),
            subtitle: GestureDetector(
              onTap: () => openDeveloperSite(context),
              child: const Text(
                'MH-DEV | محمد مهدی حق شناس'
                '\n'
                'https://haghshenasdev.github.io/',
                style: TextStyle(
                  color: Colors.blue,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> openDeveloperSite(BuildContext context) async {
    final Uri url = Uri.parse('https://haghshenasdev.github.io/');

    try {
      if (await canLaunchUrl(url)) {
        await launchUrl(url, mode: LaunchMode.externalApplication);
      } else {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('امکان باز کردن سایت وجود ندارد')),
          );
        }
      }
    } catch (e) {
      debugPrint('Open URL Error: $e');

      if (context.mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('خطا در باز کردن مرورگر')));
      }
    }
  }

  Widget _sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 24, 16, 8),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.bold,
          color: Colors.blueGrey,
        ),
        textDirection: TextDirection.rtl,
      ),
    );
  }
}

class DarkModeTile extends StatelessWidget {
  const DarkModeTile({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = context.watch<ThemeProvider>();

    return SwitchListTile(
      title: const Text('حالت تیره (Dark Mode)'),
      secondary: const Icon(Icons.dark_mode),
      value: theme.isDark,
      onChanged: (value) {
        context.read<ThemeProvider>().toggleDark(value);
      },
    );
  }
}

class FormSuggestionsSettings extends StatefulWidget {
  const FormSuggestionsSettings({super.key});

  @override
  State<FormSuggestionsSettings> createState() =>
      _FormSuggestionsSettingsState();
}

class _FormSuggestionsSettingsState extends State<FormSuggestionsSettings> {
  bool sahebName = true;
  bool guy = true;
  bool onvan = true;
  bool category = true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final values = await Future.wait([
      AppSettings.getFormSuggestionsEnabled('saheb_name'),
      AppSettings.getFormSuggestionsEnabled('guy'),
      AppSettings.getFormSuggestionsEnabled('onvan'),
      AppSettings.getFormSuggestionsEnabled('category'),
    ]);

    if (!mounted) return;

    setState(() {
      sahebName = values[0];
      guy = values[1];
      onvan = values[2];
      category = values[3];
    });
  }

  Future<void> _setValue(String field, bool value) async {
    await AppSettings.setFormSuggestionsEnabled(field, value);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SwitchListTile(
          secondary: const Icon(Icons.person_search),
          title: const Text('پیشنهاد صاحب نامه'),
          subtitle: const Text(
            'نمایش پیشنهادهای قبلی هنگام وارد کردن صاحب نامه',
          ),
          value: sahebName,
          onChanged: (value) async {
            setState(() {
              sahebName = value;
            });

            await _setValue('saheb_name', value);
          },
        ),

        SwitchListTile(
          secondary: const Icon(Icons.topic),
          title: const Text('پیشنهاد موضوع'),
          subtitle: const Text('نمایش موضوعات قبلی هنگام وارد کردن موضوع'),
          value: guy,
          onChanged: (value) async {
            setState(() {
              guy = value;
            });

            await _setValue('guy', value);
          },
        ),

        SwitchListTile(
          secondary: const Icon(Icons.person_outline),
          title: const Text('پیشنهاد گیرنده نامه'),
          subtitle: const Text('نمایش گیرنده‌های قبلی هنگام وارد کردن گیرنده'),
          value: onvan,
          onChanged: (value) async {
            setState(() {
              onvan = value;
            });

            await _setValue('onvan', value);
          },
        ),

        SwitchListTile(
          secondary: const Icon(Icons.category_outlined),
          title: const Text('پیشنهاد دسته‌بندی'),
          subtitle: const Text(
            'نمایش دسته‌بندی‌های قبلی هنگام انتخاب دسته‌بندی',
          ),
          value: category,
          onChanged: (value) async {
            setState(() {
              category = value;
            });

            await _setValue('category', value);
          },
        ),
      ],
    );
  }
}

class AutoSaveRecordFormTile extends StatefulWidget {
  const AutoSaveRecordFormTile({super.key});

  @override
  State<AutoSaveRecordFormTile> createState() => _AutoSaveRecordFormTileState();
}

class _AutoSaveRecordFormTileState extends State<AutoSaveRecordFormTile> {
  bool enabled = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final value = await AppSettings.getAutoSaveRecordForm();

    if (!mounted) return;

    setState(() {
      enabled = value;
    });
  }

  Future<void> _setValue(bool value) async {
    setState(() {
      enabled = value;
    });

    await AppSettings.setAutoSaveRecordForm(value);
  }

  @override
  Widget build(BuildContext context) {
    return SwitchListTile(
      secondary: const Icon(Icons.save_outlined),
      title: const Text('ذخیره خودکار نامه'),
      subtitle: const Text(
        'هنگام خروج از فرم، تغییرات به صورت خودکار ذخیره می‌شوند',
      ),
      value: enabled,
      onChanged: _setValue,
    );
  }
}

class SaveAndReturnAfterScanTile extends StatefulWidget {
  const SaveAndReturnAfterScanTile({super.key});

  @override
  State<SaveAndReturnAfterScanTile> createState() =>
      _SaveAndReturnAfterScanTileState();
}

class _SaveAndReturnAfterScanTileState
    extends State<SaveAndReturnAfterScanTile> {
  bool enabled = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final value = await AppSettings.getSaveAndReturnAfterScan();

    if (!mounted) return;

    setState(() {
      enabled = value;
    });
  }

  Future<void> _setValue(bool value) async {
    setState(() {
      enabled = value;
    });

    await AppSettings.setSaveAndReturnAfterScan(value);
  }

  @override
  Widget build(BuildContext context) {
    return SwitchListTile(
      secondary: const Icon(Icons.document_scanner_outlined),
      title: const Text('ذخیره و بازگشت پس از اسکن'),
      subtitle: const Text(
        'پس از موفقیت اسکن، نامه ذخیره شده و فرم بسته می‌شود',
      ),
      value: enabled,
      onChanged: _setValue,
    );
  }
}

class MonthlyBackupReminderTile extends StatefulWidget {
  const MonthlyBackupReminderTile({super.key});

  @override
  State<MonthlyBackupReminderTile> createState() =>
      _MonthlyBackupReminderTileState();
}

class _MonthlyBackupReminderTileState extends State<MonthlyBackupReminderTile> {
  bool _enabled = true;
  bool _loading = true;

  @override
  void initState() {
    super.initState();

    _load();
  }

  Future<void> _load() async {
    final value = await AppSettings.getMonthlyBackupReminderEnabled();

    if (!mounted) {
      return;
    }

    setState(() {
      _enabled = value;
      _loading = false;
    });
  }

  Future<void> _changeValue(bool value) async {
    setState(() {
      _enabled = value;
    });

    await AppSettings.setMonthlyBackupReminderEnabled(value);

    if (value) {
      await NotificationService.instance.scheduleMonthlyBackupReminder();
    } else {
      await NotificationService.instance.cancelMonthlyBackupReminder();
    }
  }

  @override
  Widget build(BuildContext context) {
    return SwitchListTile(
      secondary: Icon(_enabled ? Icons.backup_outlined : Icons.backup_outlined),
      title: const Text('یادآور پشتیبان‌گیری ماهانه'),
      subtitle: Text(
        _enabled
            ? 'اول هر ماه برای تهیه نسخه پشتیبان یادآوری می‌شود'
            : 'یادآور پشتیبان‌گیری غیرفعال است',
      ),
      value: _enabled,
      onChanged: _loading ? null : _changeValue,
    );
  }
}

class ReminderNotificationTimeTile extends StatefulWidget {
  const ReminderNotificationTimeTile({super.key});

  @override
  State<ReminderNotificationTimeTile> createState() =>
      _ReminderNotificationTimeTileState();
}

class _ReminderNotificationTimeTileState
    extends State<ReminderNotificationTimeTile> {
  TimeOfDay _time = const TimeOfDay(hour: 9, minute: 0);
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final time = await NotificationService.instance
        .getReminderNotificationTime();

    if (!mounted) return;

    setState(() {
      _time = time;
      _loading = false;
    });
  }

  Future<void> _selectTime() async {
    final selected = await showTimePicker(
      context: context,
      initialTime: _time,
      helpText: 'زمان نمایش اعلان‌های یادآور',
      cancelText: 'انصراف',
      confirmText: 'تأیید',
    );

    if (selected == null) return;

    setState(() {
      _loading = true;
    });

    try {
      await NotificationService.instance.setReminderNotificationTime(selected);

      if (!mounted) return;

      setState(() {
        _time = selected;
        _loading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'زمان اعلان‌ها روی ${selected.format(context)} تنظیم شد.',
            textDirection: TextDirection.rtl,
          ),
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _loading = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'خطا در تغییر زمان اعلان:\n$e',
            textDirection: TextDirection.rtl,
          ),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: const Icon(Icons.schedule_rounded),
      title: const Text('زمان اعلان یادآور'),
      subtitle: Text(
        _loading
            ? 'در حال بارگذاری...'
            : 'هر روز ساعت ${_time.format(context)}',
        textDirection: TextDirection.rtl,
      ),
      trailing: _loading
          ? const SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(strokeWidth: 2),
            )
          : Text(
              _time.format(context),
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
      onTap: _loading ? null : _selectTime,
    );
  }
}
